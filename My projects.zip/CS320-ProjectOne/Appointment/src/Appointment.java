import java.util.Date;

public class Appointment {
    private String UID;
    private Date Date;
    private String Description;

    public Appointment(String id, Date date, String description) {
        if (id == null || date == null || description == null) {
            throw new IllegalArgumentException("Incomplete field");
        }
        if (id.length() > 10) {
            throw new IllegalArgumentException("Enter the ID less than 10 digits");
        }
        if (date.before(new Date())) {
            throw new IllegalArgumentException("Past date not acceptable");
        }
        if (description.length() > 50) {
            throw new IllegalArgumentException("Plz enter the description more than 10 characters");
        }
        this.UID = id;
        this.Date = date;
        this.Description = description;
    }

    public String getId() {
        return UID;
    }

    public Date getDate() {
        return Date;
    }

    public String getDescription() {
        return Description;
    }

}
