import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private Map<String, Appointment> apnmtMap = new HashMap<String, Appointment>();

    public void addAppointment(String UID, Appointment appointment){
        apnmtMap.put(UID, appointment);
    }
    public void deleteAppointment(String UID){
        apnmtMap.remove(UID);
    }
}
