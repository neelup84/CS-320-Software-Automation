import org.junit.Test;

import java.util.Calendar;

public class AppointmentServiceTest {

    @Test
    public void addAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String UID= "12132323";
        Calendar calendar = Calendar.getInstance();
        calendar.set(2022, 11, 23);
        appointmentService.addAppointment(UID, new
                Appointment(UID, calendar.getTime(), "Description"));
    }

    @Test
    public void DeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String UID = "87327839";
        Calendar calendar = Calendar.getInstance();
        calendar.set(2025, 07, 30);
        appointmentService.addAppointment(UID, new
                Appointment(UID, calendar.getTime(), "Delete"));
        appointmentService.deleteAppointment(UID);
    }

}
