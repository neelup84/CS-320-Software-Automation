import org.junit.Test;

import java.util.Calendar;

public class AppointmentTest {

    @Test
    public void normal() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2024, 07, 30);
        new Appointment("78949",calendar.getTime(),"DETAILS");
    }

    @Test(expected = IllegalArgumentException.class)
    public void idIsNull() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2022, 01, 01);
        new Appointment(null,calendar.getTime(),"DETAILS");
    }

    @Test(expected = IllegalArgumentException.class)
    public void idIsMoreThan10Characters() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2022, 01, 01);
        new Appointment("Not less than 10char plz",calendar.getTime(),"DETAILS");
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateIsInThePast() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2003, 01, 10);
        new Appointment("12345",calendar.getTime(),"DETAILS");
    }

    @Test(expected = IllegalArgumentException.class)
    public void descriptionIsMoreThan50Characters() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2024, 07, 30);
        new Appointment("12345",calendar.getTime(),"ABCDEFG" +
		        "HIJKL" +
		        "MNOP QRST UV " +
		        "WX YZ now I  " +
		        "Know my unit testing");
    }
}


