import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TaskService {

   
    //Instance of ArrayList of Task
    public static List<Task> tasks = new ArrayList<>();

    public static void main(String[] args) {

        //Instance of TaskService
        TaskService service = new TaskService();
        //It passes the three strings parameters of Unique Id, Name and Description to the Task public constructor as per the requirement
        // and also add three task 
        service.addTask(new Task("101", "Dancing", "Dance on any songs"));
        service.addTask(new Task("102", "Playing", "Playing basketball"));
        service.addTask(new Task("103", "Walking", "Go for long walk"));
        
        //It shows added and updated task myobj
        for (Task myobj : tasks) {
            System.out.println(myobj);
        }
       
        service.addTask(new Task("101", "Painting", "Paint and craft"));

        System.out.println("Task ID Delete @102");
        service.deleteTask("102");
        System.out.println("Task ID update @103");
        service.update(new Task("103", "Walking", "Go for a long walk"));

        //display all added and updated Task object
        for (Task myobj : tasks) {
            System.out.println(myobj);
        }
    }

    /*
     *
     * Here the Task class containing Id, Name and Description variables
     */
    public boolean addTask(Task task) {
        int index = getIndex(task);

        //It Check the Id if it doesn't exist, name and description and return to true or false
        if (index < 0 && validateID(task.getId()) && validateName(task.getName()) && validateDescription(task.getDescription())) {
            tasks.add(task);
            return true;
        }
        
        return false;
    }

    /*
     *
     * @param id
     *
     * delete Task object when Task ID exist
     *
     */
    public void deleteTask(String id) {
        //invoke getIndex(Task) method
        //create new instance of Task object and pass the String ID in the constructor, set name and description as empty or null

        int index = getIndex(new Task(id, "", ""));
        
        //It checks if index is greater than or equal to 0 
        if (index >= 0)
            tasks.remove(index);
    }

    /*
     *
     * @param task
     * 
     * update Task object if same ID and valid name and description
     */
    public void update(Task task) {
        for (Task obj : tasks) {
            if (obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())) {
                obj.setName(task.getName());
                obj.setDescription(task.getDescription());
            }
        }
    }

    /**
     *
     * @param task
     * @return integer data type
     * 
     * use Collections binary search by Task ID
     * return positive integer from 0 to N if ID is found
     * return negative integer if ID is not found
     */
    public int getIndex(Task task) {
        int index = Collections.binarySearch(tasks, task, Task.compareID);
        return index;
    }

    /**
     * 
     * @param id
     * @return true or false
     * 
     * validate id parameter, if not null and length is less than or equal to 10
     */
    public boolean validateID(String Id) {  // here I have errors earlier, I used == sign and used Long Id instead of boolean which gave me errors
        if (Id != null && Id.length() <= 10)
            return true;

        return false;
    }

    /**
     * 
     * @param name
     * @return true or false
     * 
     * validate name parameter, if not null and length is less than or equal to 20
     */
    public boolean validateName(String Name) {
        if (Name != null && Name.length() <= 20)
            return true;

        return false;
    }

    /**
     * 
     * @param description
     * @return true or false
     * 
     * validate description parameter, if not null and length is less than or equal to 50
     */
    public boolean validateDescription(String Description) {
        if (Description != null && Description.length() <= 50)
            return true;

        return false;
    }
}