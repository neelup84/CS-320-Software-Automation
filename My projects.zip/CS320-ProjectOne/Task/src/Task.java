

import java.util.Comparator;

public class Task {

    //private access modifier for encapsulation
    private String Id;
    private String Name;
    private String Description;

    //public constructor of Task object accepting 3 String parameters
    public Task(String id, String name, String description) {
        this.Id = id;
        this.Name = name;
        this.Description = description;
    }

    //public getters to get the value of private variable
    public String getId() {
        return Id;
    }

    //public setters to set the value of private variable
    public void setId(String id) {
        this.Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }
    
    /**
     * 
     * @param obj
     * @return true | false
     * 
     * check the equality of two Task object
     * return true if both object are equal
     * return false if passed Object is null
     * return false if getClass() method is not equal
     * return true if id of both object are equal otherwise false
     */
    @Override
    public boolean equals(Object myobj) {
        if (this == myobj)
            return true;

        if (myobj == null)
            return false;

        if (this.getClass() != myobj.getClass())
            return false;

        Task t = (Task) myobj;
        return getId().equals(t.getId());
    }

    /**
     * use Comparator interface
     * override the compare method comparing the id variable of two Task object
     */
    public static Comparator<Task> compareID = new Comparator<Task>() {
        @Override
        public int compare(Task t1, Task t2) {
            return t1.getId().compareTo(t2.getId());
        }
    };

    /**
     * @return String data type concatenated String value of Task object
     * displaying the id, name and description
     */
    @Override
    public String toString() {
        return "Task ID: " + getId() + "\nName: " + getName() + "\nDescription: " + getDescription() + "\n";
    }

}
        	