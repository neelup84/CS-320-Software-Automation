import org.junit.Test;

public class TaskTest {

  @Test public void createValidTaskData() {
      Task task = new Task("101", "Palying", "Playing basketball");
      System.out.println(task);
      
   }
  
  @Test public void createValidTaskData1() {
      Task task = new Task("102", "Dancing", "Dance on any songs");
      System.out.println(task);
}
  
  
  @Test public void createValidTaskData2() {
      Task task = new Task("103", "Walking", "Go for a long walk");
      System.out.println(task);
}
 
}
  
  
