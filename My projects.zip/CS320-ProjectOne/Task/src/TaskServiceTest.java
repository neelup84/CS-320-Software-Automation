import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

public class TaskServiceTest {
   
   public static List<Task> tasks = new ArrayList<>();

   @Test public void validTaskData() {
      Task task = new Task("101", "Dancing", "Dance on any songs");
      addTask(task);
      System.out.println("New Task: " + tasks);
      
   }
   
   @Test public void invalidID() {      
      Task task = new Task("102", "Playing", "Playing basketball");
      addTask(task);
      
   }
   
   @Test public void invalidName() {      
      Task task = new Task("103", "Walking", "Go for a long walk");
      addTask(task);
      
   }
   
   @Test public void invalidDescription() {      
      Task task = new Task("102", "Playing", "Playing Basketball");
      addTask(task);
     
   }
   
   @Test public void existingID() {      
      Task task = new Task("101", "Dancing", "Dance on any Song");
      addTask(task);
      
   }
   
   @Test public void updateTask() {      
      Task task = new Task("101", "Painting", "Paint and make crafts");
      update(task);
      System.out.println("Updated: " + tasks); 
   }
   
   @Test public void deleteTask() {
      deleteTask("102");
  
   }   
   
   public boolean addTask(Task task) {
        //It checks and perform binary search to wether the ID exists and if ID is not found, It will return the value negative
        int index = getIndex(task);

        //It validate if Id doesn't exist and name and description
        if (index < 0 && validateID(task.getId()) && validateName(task.getName()) && validateDescription(task.getDescription())) {
            tasks.add(task);
            return true;
        }
        
        return false;
    }
    
    /*
     *
     * @param id
     *
     * If task Id exist then delete Task obj
     *
     */
    public void deleteTask(String id) {
        //It creates new instance of Task myobject and pass the StrinID in the constructor and sets the Name and Description as empty or null
        int index = getIndex(new Task(id, "", ""));
        
        //check if index is greater than or equal to 0
        if (index >= 0)
            tasks.remove(index);
    }

    /*
     *
     * @param task
     * 
     * update Task object if same ID and valid Name and Description
     */
    public void update(Task task) {
        for (Task obj : tasks) {
            if (obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())) {
                obj.setName(task.getName());
                obj.setDescription(task.getDescription());
            }
        }
    }
    
    /*
     *
     * @param task
     *  Task Id is used for collections binary and return positive or negative integer
     */
    public int getIndex(Task task) {
        int index = Collections.binarySearch(tasks, task, Task.compareID);
        return index;
    }

    /*
     * 
     * @param id
     * 
     * It also validate Id parameter, if not null and length is less than or equal to 10, It return true or false
     */
    public boolean validateID(String id) {
        if (id != null && id.length() <= 10)
            return true;

        return false;
    }

    /*
     * 
     * @param name
     * @return true or false
     * 
     * validate name parameter, if not null and length is less than or equal to 20 it returns true or false
     */
    public boolean validateName(String name) {
        if (name != null && name.length() <= 20)
            return true;

        return false;
    }

    /*
     * 
     * @param descri 
     * 
     * It validate Descr parameter, if not null and length is less than or equal to 50, it returns true or false
     */
    public boolean validateDescription(String description) {
        if (description != null && description.length() <= 50)
            return true;

        return false;
    }
}
