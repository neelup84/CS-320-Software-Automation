import static org.junit.Assert.*;
import org.junit.Test;


public class ContactServiceTest1Test {

   // testing the add method 
   @Test
   public void testMethodAddPass() {
       ContactService1 cs = new ContactService1();
       Contact1 abc = new Contact1("123", "Neelima", "Patniak", "1771 Omaha, NE");
       Contact1 def = new Contact1("111", "Liz","Williams","1212 CA MA");
       Contact1 ghi = new Contact1("789", "Vainav", "Patnaik", "12345 Omaha, NE");
       assertEquals(true, cs.add(abc));
       assertEquals(true, cs.add(def));
       assertEquals(true, cs.add(ghi));
   }

   
   @Test
   public void testMethodAddFail() {
       ContactService1 cs = new ContactService1();
       Contact1 abc = new Contact1("123", "Neelima", "Patniak", "1771 Omaha, NE");
       Contact1 def = new Contact1("111", "Liz","Williams","1212 CA MA");
       Contact1 hij = new Contact1("789", "Vainav", "Patnaik", "12345 Omaha, NE");
       assertEquals(true, cs.add(abc));
       assertEquals(false, cs.add(abc));
       assertEquals(true, cs.add(def));
       assertEquals(true, cs.add(hij));
   }

   //the delete method
   @Test
   public void testMethodDeletePass() {
       ContactService1 cs = new ContactService1();
       Contact1 abc = new Contact1("123", "Neelima", "Patniak", "1771 Omaha, NE");
       Contact1 def = new Contact1("111", "Liz","Williams","1212 CA MA");
       Contact1 hij = new Contact1("789", "Vainav", "Patnaik", "12345 Omaha, NE");
       assertEquals(true, cs.add(abc));
       assertEquals(true, cs.add(def));
       assertEquals(true, cs.add(hij));

       assertEquals(true, cs.remove("789"));
       assertEquals(true, cs.remove("123"));
   }

   //the delete method 
   @Test
   public void testMethodDeleteFail() {
       ContactService1 cs = new ContactService1();
       Contact1 x1 = new Contact1("111","Liz", "Williams", "1212 CA MA");
       Contact1 x2 = new Contact1("222","Amanda", "Segabart", "2323 LA ST");
       Contact1 x3 = new Contact1("333","Puja", "Patel", "4545 KS NE");
       assertEquals(true, cs.add(x1));
       assertEquals(true, cs.add(x3));
       assertEquals(true, cs.add(x2));

       assertEquals(false, cs.remove("444"));
       assertEquals(true, cs.remove("111"));
   }

   // the update method 
   @Test
   public void testUpdatePass() {
       ContactService1 cs = new ContactService1();
       Contact1 d1 = new Contact1("123","Liz", "Williams", "1212 CA MA");
       Contact1 d2 = new Contact1("456","Amanda", "Segabart", "2323 LA ST");
       Contact1 d3 = new Contact1("789","Puja", "Patel", "4545 KS NE");
       assertEquals(true, cs.add(d1));
       assertEquals(true, cs.add(d3));
       assertEquals(true, cs.add(d2));

       assertEquals(true, cs.update("789", "Lizo", "mno", "xyz"));
       assertEquals(true, cs.update("456", "Jade", "ssk", "1324 LA ST"));
   }

 
   @Test
   public void testUpdateFail() {
       ContactService1 cs = new ContactService1();
       Contact1 t1 = new Contact1("123","Liz", "Williams", "1212 CA MA");
       Contact1 t2 = new Contact1("456","Amanda", "Segabart", "2323 LA ST");
       Contact1 t3 = new Contact1("789","Puja", "Patel", "4545 KS NE");
       assertEquals(true, cs.add(t1));
       assertEquals(true, cs.add(t2));
       assertEquals(true, cs.add(t3));

       assertEquals(false, cs.update("788", "Seth", "Pi", ""));
       assertEquals(true, cs.update("456", "Jim", "Max", "124 LA ST"));
   }

}