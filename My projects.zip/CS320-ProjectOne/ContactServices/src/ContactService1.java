import java.util.ArrayList;

public class ContactService1 {
   /* contact list */
   private ArrayList<Contact1> contacts;

   /* default constructor */
   public ContactService1() {
       contacts = new ArrayList<>();
   }

   /* this is a method*/
   public boolean add(Contact1 contact) {
       /* first we determine if the contact is already present */
       boolean alreadyPresent = false;
       for (Contact1 a : contacts) {
           if (a.equals(contact)) {
               alreadyPresent = true;
           }
       }
       /*  we add contact if not present, and it return it true */
       if (!alreadyPresent) {
           contacts.add(contact);
           System.out.println("Adding contact");
           return true;
       } else {
           System.out.println("This contact is already exists");
           return false;
       }
   }

   /* this method remove a contact with given contactId if present in our list */
   public boolean remove(String contactID) {
       for (Contact1 a : contacts) {
           if (a.getContactID().equals(contactID)) {
               contacts.remove(a);
               System.out.println("Contact is deleted");
               return true;
           }
       }
       System.out.println("Contact not present");
       return false;
   }

   /*
   * this method updates the contact of the given contactID, if found updates its
   * First name, last name and number address. If there is no details the string pass empty
   */
   public boolean update(String contactID, String firstName, String lastName, String numberAddress) {
       for (Contact1 b : contacts) {
           if (b.getContactID().equals(contactID)) {
               if (firstName.equals(""))
                   b.setFirstName(firstName);
               if (lastName.equals(""))
                   b.setLastName(lastName);
               if (numberAddress.equals(""))
                   b.setNumberAddress(numberAddress);
               System.out.println("Contact updated");
               return true;
           }
       }
       System.out.println("No Contact present");
       return false;
   }

public Object add1(Contact1 c1) {
	
	return null;
}

}
